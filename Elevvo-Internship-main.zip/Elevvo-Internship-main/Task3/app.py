import streamlit as st
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import plotly.express as px
import plotly.graph_objects as go
from sklearn.preprocessing import StandardScaler

# Page configuration
st.set_page_config(
    page_title="Forest Cover Type Prediction",
    page_icon="🌲",
    layout="wide"
)

# Load models and data
@st.cache_data
def load_models_and_data():
    try:
        rf_model = joblib.load('best_random_forest_model.pkl')
        xgb_model = joblib.load('best_xgboost_model.pkl')
        scaler = joblib.load('feature_scaler.pkl')
        model_info = joblib.load('forest_model_info.pkl')
        
        # Load sample data
        sample_data = pd.read_csv('forest_sample_data.csv')
        
        return rf_model, xgb_model, scaler, model_info, sample_data
    except FileNotFoundError as e:
        st.error(f"Model files not found. Please run the preprocessing notebook first. Error: {e}")
        return None, None, None, None, None

# Load everything
rf_model, xgb_model, scaler, model_info, sample_data = load_models_and_data()

def main():
    st.title("🌲 Forest Cover Type Prediction")
    st.markdown("Predict forest cover type based on cartographic and environmental features")
    st.markdown("---")
    
    if rf_model is None:
        st.stop()
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", [
        "🔮 Prediction", 
        "📊 Model Performance", 
        "📈 Data Exploration",
        "🎯 Feature Analysis"
    ])
    
    if page == "🔮 Prediction":
        prediction_page()
    elif page == "📊 Model Performance":
        model_performance_page()
    elif page == "📈 Data Exploration":
        data_exploration_page()
    elif page == "🎯 Feature Analysis":
        feature_analysis_page()

def prediction_page():
    st.header("🔮 Predict Forest Cover Type")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Environmental Features")
        
        with st.form("prediction_form"):
            # Cartographic features
            st.write("**Cartographic Information**")
            col_a, col_b = st.columns(2)
            
            with col_a:
                elevation = st.slider("Elevation (meters)", 1500, 4000, 2500)
                aspect = st.slider("Aspect (degrees)", 0, 360, 180)
                slope = st.slider("Slope (degrees)", 0, 60, 15)
                horizontal_distance_hydrology = st.slider("Distance to Hydrology (m)", 0, 1000, 200)
                vertical_distance_hydrology = st.slider("Vertical Distance to Hydrology (m)", -200, 600, 50)
            
            with col_b:
                horizontal_distance_roadways = st.slider("Distance to Roadways (m)", 0, 7000, 2000)
                distance_fire_points = st.slider("Distance to Fire Points (m)", 0, 7000, 3000)
                hillshade_9am = st.slider("Hillshade 9am", 0, 255, 200)
                hillshade_noon = st.slider("Hillshade Noon", 0, 255, 220)
                hillshade_3pm = st.slider("Hillshade 3pm", 0, 255, 150)
            
            st.write("**Wilderness Area**")
            wilderness_area = st.selectbox("Select Wilderness Area", 
                                         ["None", "Area 1", "Area 2", "Area 3", "Area 4"])
            
            st.write("**Soil Type**")
            soil_type = st.selectbox("Select Soil Type (1-40)", 
                                   ["None"] + [f"Soil Type {i}" for i in range(1, 41)])
            
            submitted = st.form_submit_button("🎯 Predict Forest Cover Type", type="primary")
        
        if submitted:
            # Prepare input data
            input_data = prepare_input_data(
                elevation, aspect, slope, horizontal_distance_hydrology,
                vertical_distance_hydrology, horizontal_distance_roadways,
                distance_fire_points, hillshade_9am, hillshade_noon, hillshade_3pm,
                wilderness_area, soil_type
            )
            
            # Make predictions
            rf_prediction = rf_model.predict([input_data])[0]
            xgb_prediction = xgb_model.predict([input_data])[0]
            
            # Convert predictions back to original class labels (0-6 -> 1-7)
            rf_prediction_original = model_info['class_mapping'][rf_prediction]
            xgb_prediction_original = model_info['class_mapping'][xgb_prediction]
            
            # Get prediction probabilities
            rf_proba = rf_model.predict_proba([input_data])[0]
            xgb_proba = xgb_model.predict_proba([input_data])[0]
            
            with col2:
                st.subheader("🎯 Prediction Results")
                
                # Display predictions with original class numbers
                rf_cover_name = model_info['class_names'].get(rf_prediction, f"Type {rf_prediction_original}")
                xgb_cover_name = model_info['class_names'].get(xgb_prediction, f"Type {xgb_prediction_original}")
                
                st.metric("Random Forest", f"Type {rf_prediction_original}", help=rf_cover_name)
                st.metric("XGBoost", f"Type {xgb_prediction_original}", help=xgb_cover_name)
                
                # Show confidence
                rf_confidence = max(rf_proba) * 100
                xgb_confidence = max(xgb_proba) * 100
                
                st.write(f"**Confidence Levels:**")
                st.write(f"• Random Forest: {rf_confidence:.1f}%")
                st.write(f"• XGBoost: {xgb_confidence:.1f}%")
                
                # Cover type descriptions
                st.subheader("🌲 Cover Type Information")
                if rf_prediction == xgb_prediction:
                    cover_description = get_cover_type_description(rf_prediction_original)
                    st.success(f"**Both models agree: {rf_cover_name}**")
                    st.write(cover_description)
                else:
                    st.warning("**Models disagree on prediction**")
                    st.write(f"RF suggests: {rf_cover_name}")
                    st.write(f"XGB suggests: {xgb_cover_name}")
                
                # Probability distribution
                st.subheader("📊 Prediction Probabilities")
                prob_df = pd.DataFrame({
                    'Cover Type': [f"Type {i+1}" for i in model_info['target_classes']],  # Convert back to 1-7
                    'Random Forest': rf_proba,
                    'XGBoost': xgb_proba
                })
                
                fig_proba = px.bar(prob_df, x='Cover Type', y=['Random Forest', 'XGBoost'],
                                  title="Prediction Probabilities", barmode='group')
                st.plotly_chart(fig_proba, use_container_width=True)

def prepare_input_data(elevation, aspect, slope, h_dist_hydro, v_dist_hydro,
                      h_dist_roads, dist_fire, hill_9am, hill_noon, hill_3pm,
                      wilderness_area, soil_type):
    """Prepare input data for prediction"""
    
    # Initialize feature vector with zeros
    feature_vector = np.zeros(len(model_info['feature_columns']))
    feature_names = model_info['feature_columns']
    
    # Set cartographic features
    cartographic_values = {
        'Elevation': elevation,
        'Aspect': aspect,
        'Slope': slope,
        'Horizontal_Distance_To_Hydrology': h_dist_hydro,
        'Vertical_Distance_To_Hydrology': v_dist_hydro,
        'Horizontal_Distance_To_Roadways': h_dist_roads,
        'Hillshade_9am': hill_9am,
        'Hillshade_Noon': hill_noon,
        'Hillshade_3pm': hill_3pm,
        'Horizontal_Distance_To_Fire_Points': dist_fire
    }
    
    for feature, value in cartographic_values.items():
        if feature in feature_names:
            idx = feature_names.index(feature)
            feature_vector[idx] = value
    
    # Set wilderness area (one-hot encoded)
    if wilderness_area != "None":
        wilderness_col = f"Wilderness_Area_{wilderness_area.split()[-1]}"
        if wilderness_col in feature_names:
            idx = feature_names.index(wilderness_col)
            feature_vector[idx] = 1
    
    # Set soil type (one-hot encoded)
    if soil_type != "None":
        soil_col = f"Soil_Type_{soil_type.split()[-1]}"
        if soil_col in feature_names:
            idx = feature_names.index(soil_col)
            feature_vector[idx] = 1
    
    # Add engineered features
    if 'Distance_To_Hydrology_Roadways' in feature_names:
        idx = feature_names.index('Distance_To_Hydrology_Roadways')
        feature_vector[idx] = h_dist_hydro + h_dist_roads
    
    if 'Distance_To_Fire_Hydrology' in feature_names:
        idx = feature_names.index('Distance_To_Fire_Hydrology')
        feature_vector[idx] = dist_fire + h_dist_hydro
    
    if 'Hillshade_Mean' in feature_names:
        idx = feature_names.index('Hillshade_Mean')
        feature_vector[idx] = (hill_9am + hill_noon + hill_3pm) / 3
    
    if 'Hillshade_Range' in feature_names:
        idx = feature_names.index('Hillshade_Range')
        feature_vector[idx] = max(hill_9am, hill_noon, hill_3pm) - min(hill_9am, hill_noon, hill_3pm)
    
    # Set elevation bins
    if elevation < 2200:
        bin_name = 'Elevation_Very_Low'
    elif elevation < 2700:
        bin_name = 'Elevation_Low'
    elif elevation < 3200:
        bin_name = 'Elevation_Medium'
    elif elevation < 3700:
        bin_name = 'Elevation_High'
    else:
        bin_name = 'Elevation_Very_High'
    
    if bin_name in feature_names:
        idx = feature_names.index(bin_name)
        feature_vector[idx] = 1
    
    return feature_vector

def get_cover_type_description(cover_type):
    """Get description for each forest cover type"""
    descriptions = {
        1: "🌲 **Spruce/Fir**: Dominant at high elevations and cold climates. Typically found in areas with heavy snowfall.",
        2: "🌲 **Lodgepole Pine**: Fast-growing pine species, often the first to regenerate after forest fires.",
        3: "🌲 **Ponderosa Pine**: Large pine species preferring dry, well-drained soils at moderate elevations.",
        4: "🌳 **Cottonwood/Willow**: Deciduous trees typically found near water sources and in riparian zones.",
        5: "🌳 **Aspen**: Deciduous trees with distinctive white bark, often found in groves at moderate to high elevations.",
        6: "🌲 **Douglas-fir**: Large coniferous trees, important timber species, adaptable to various conditions.",
        7: "🌲 **Krummholz**: Stunted, wind-shaped trees found at treeline, adapted to harsh alpine conditions."
    }
    return descriptions.get(cover_type, f"Forest cover type {cover_type}")

def model_performance_page():
    st.header("📊 Model Performance Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🎯 Model Accuracy Comparison")
        
        performance = model_info['model_performance']
        
        # Create performance comparison
        models = ['Random Forest', 'XGBoost', 'Best RF', 'Best XGB']
        accuracies = [
            performance['random_forest']['accuracy'],
            performance['xgboost']['accuracy'],
            performance['best_rf']['accuracy'],
            performance['best_xgb']['accuracy']
        ]
        
        fig_acc = px.bar(x=models, y=accuracies, 
                        title="Model Accuracy Comparison",
                        color=accuracies, color_continuous_scale='viridis')
        fig_acc.update_layout(showlegend=False, yaxis_range=[0.8, 1.0])
        st.plotly_chart(fig_acc, use_container_width=True)
        
        # Display detailed metrics
        st.write("**Detailed Performance Metrics:**")
        for model_name, metrics in performance.items():
            with st.expander(f"{model_name.replace('_', ' ').title()}"):
                st.write(f"Test Accuracy: {metrics['accuracy']:.4f}")
                if 'cv_mean' in metrics:
                    st.write(f"CV Mean: {metrics['cv_mean']:.4f}")
                    st.write(f"CV Std: {metrics['cv_std']:.4f}")
                if 'best_params' in metrics:
                    st.write("Best Parameters:")
                    for param, value in metrics['best_params'].items():
                        st.write(f"  • {param}: {value}")
    
    with col2:
        st.subheader("🏆 Best Model Summary")
        
        # Find best model
        best_model = max(performance.items(), key=lambda x: x[1]['accuracy'])
        best_name = best_model[0].replace('_', ' ').title()
        best_accuracy = best_model[1]['accuracy']
        
        st.success(f"**Best Performing Model: {best_name}**")
        st.metric("Best Accuracy", f"{best_accuracy:.4f}")
        
        # Cover type distribution
        if sample_data is not None:
            st.subheader("📊 Dataset Overview")
            # Convert back to original class labels for display
            sample_data_display = sample_data.copy()
            sample_data_display['Cover_Type'] = sample_data_display['Cover_Type'] + 1  # Convert 0-6 back to 1-7
            cover_counts = sample_data_display['Cover_Type'].value_counts().sort_index()
            
            fig_dist = px.pie(values=cover_counts.values, 
                             names=[f"Type {i}" for i in cover_counts.index],
                             title="Cover Type Distribution")
            st.plotly_chart(fig_dist, use_container_width=True)
    
    # Model evaluation visualizations
    try:
        st.subheader("📈 Model Evaluation Visualizations")
        eval_img = Image.open('model_evaluation.png')
        st.image(eval_img, caption="Confusion Matrices and Feature Importance", use_column_width=True)
    except FileNotFoundError:
        st.warning("Model evaluation visualization not found. Please run the preprocessing notebook.")

def data_exploration_page():
    st.header("📈 Data Exploration")
    
    # Display exploration visualizations
    try:
        st.subheader("🔍 Exploratory Data Analysis")
        exploration_img = Image.open('forest_exploration.png')
        st.image(exploration_img, caption="Comprehensive Data Exploration", use_column_width=True)
    except FileNotFoundError:
        st.warning("Exploration visualization not found. Please run the preprocessing notebook.")
    
    # Interactive data exploration
    if sample_data is not None:
        st.subheader("🌲 Interactive Data Exploration")
        
        # Convert Cover_Type back to original labels for visualization
        sample_data_viz = sample_data.copy()
        sample_data_viz['Cover_Type'] = sample_data_viz['Cover_Type'] + 1  # Convert 0-6 back to 1-7
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Elevation vs Cover Type
            fig_elev = px.box(sample_data_viz, x='Cover_Type', y='Elevation',
                             title="Elevation Distribution by Cover Type")
            st.plotly_chart(fig_elev, use_container_width=True)
            
            # Aspect vs Slope scatter
            fig_aspect = px.scatter(sample_data_viz, x='Aspect', y='Slope', 
                                   color='Cover_Type',
                                   title="Aspect vs Slope (colored by Cover Type)")
            st.plotly_chart(fig_aspect, use_container_width=True)
        
        with col2:
            # Hillshade patterns
            hillshade_data = sample_data_viz[['Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm', 'Cover_Type']].melt(
                id_vars=['Cover_Type'], var_name='Time', value_name='Hillshade'
            )
            fig_hillshade = px.box(hillshade_data, x='Time', y='Hillshade', 
                                  color='Cover_Type',
                                  title="Hillshade Patterns Throughout Day")
            st.plotly_chart(fig_hillshade, use_container_width=True)
            
            # Distance relationships
            fig_dist = px.scatter(sample_data_viz, 
                                 x='Horizontal_Distance_To_Hydrology', 
                                 y='Horizontal_Distance_To_Fire_Points',
                                 color='Cover_Type',
                                 title="Distance to Hydrology vs Fire Points")
            st.plotly_chart(fig_dist, use_container_width=True)
        
        # Data summary
        st.subheader("📊 Dataset Summary")
        st.write(f"**Sample size:** {len(sample_data):,} records")
        st.write(f"**Features:** {len(model_info['feature_columns'])} total features")
        st.write(f"**Cover types:** {len(model_info['target_classes'])} classes")
        
        # Feature statistics
        cartographic_features = ['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology',
                               'Vertical_Distance_To_Hydrology', 'Horizontal_Distance_To_Roadways']
        
        if all(feat in sample_data.columns for feat in cartographic_features):
            st.write("**Cartographic Features Summary:**")
            st.dataframe(sample_data[cartographic_features].describe())

def feature_analysis_page():
    st.header("🎯 Feature Importance Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🌳 Random Forest Feature Importance")
        
        rf_importance = pd.DataFrame(model_info['feature_importance_rf'])
        top_rf_features = rf_importance.head(15)
        
        fig_rf = px.bar(top_rf_features, x='Importance', y='Feature',
                       orientation='h', title="Top 15 Features - Random Forest")
        fig_rf.update_layout(yaxis={'categoryorder':'total ascending'})
        st.plotly_chart(fig_rf, use_container_width=True)
        
        st.write("**Top 5 Features:**")
        for i, row in top_rf_features.head(5).iterrows():
            st.write(f"{i+1}. **{row['Feature']}**: {row['Importance']:.4f}")
    
    with col2:
        st.subheader("🚀 XGBoost Feature Importance")
        
        xgb_importance = pd.DataFrame(model_info['feature_importance_xgb'])
        top_xgb_features = xgb_importance.head(15)
        
        fig_xgb = px.bar(top_xgb_features, x='Importance', y='Feature',
                        orientation='h', title="Top 15 Features - XGBoost")
        fig_xgb.update_layout(yaxis={'categoryorder':'total ascending'})
        st.plotly_chart(fig_xgb, use_container_width=True)
        
        st.write("**Top 5 Features:**")
        for i, row in top_xgb_features.head(5).iterrows():
            st.write(f"{i+1}. **{row['Feature']}**: {row['Importance']:.4f}")
    
    # Feature comparison
    st.subheader("🔄 Feature Importance Comparison")
    
    # Merge top features from both models
    rf_top = set(rf_importance.head(10)['Feature'])
    xgb_top = set(xgb_importance.head(10)['Feature'])
    common_features = rf_top.intersection(xgb_top)
    
    st.write(f"**Common Important Features ({len(common_features)} features):**")
    for i, feature in enumerate(sorted(common_features), 1):
        rf_rank = rf_importance[rf_importance['Feature'] == feature].index[0] + 1
        xgb_rank = xgb_importance[xgb_importance['Feature'] == feature].index[0] + 1
        st.write(f"{i}. **{feature}** (RF rank: {rf_rank}, XGB rank: {xgb_rank})")
    
    # Feature categories analysis
    st.subheader("📊 Feature Categories")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.write("**Cartographic Features:**")
        cartographic = ['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology',
                       'Vertical_Distance_To_Hydrology', 'Horizontal_Distance_To_Roadways',
                       'Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm', 
                       'Horizontal_Distance_To_Fire_Points']
        for feat in cartographic:
            if feat in rf_importance['Feature'].values:
                importance = rf_importance[rf_importance['Feature'] == feat]['Importance'].iloc[0]
                st.write(f"• {feat}: {importance:.3f}")
    
    with col2:
        st.write("**Wilderness Areas:**")
        wilderness_features = [f for f in rf_importance['Feature'] if 'Wilderness_Area' in f]
        for feat in wilderness_features[:5]:
            importance = rf_importance[rf_importance['Feature'] == feat]['Importance'].iloc[0]
            st.write(f"• {feat}: {importance:.3f}")
    
    with col3:
        st.write("**Top Soil Types:**")
        soil_features = [f for f in rf_importance['Feature'] if 'Soil_Type' in f][:5]
        for feat in soil_features:
            importance = rf_importance[rf_importance['Feature'] == feat]['Importance'].iloc[0]
            st.write(f"• {feat}: {importance:.3f}")

def add_footer():
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "🌲 Forest Cover Type Prediction | Built with Random Forest & XGBoost"
        "</div>", 
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()
    add_footer()