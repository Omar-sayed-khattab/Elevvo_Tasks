import streamlit as st
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import plotly.express as px
import plotly.graph_objects as go
from sklearn.preprocessing import StandardScaler

# Page configuration
st.set_page_config(
    page_title="Customer Segmentation",
    page_icon="🛍️",
    layout="wide"
)

# Load models and data
@st.cache_data
def load_models_and_data():
    try:
        kmeans_model = joblib.load('kmeans_model.pkl')
        scaler = joblib.load('scaler.pkl')
        clustering_info = joblib.load('clustering_info.pkl')
        
        # Try to load DBSCAN if available
        try:
            dbscan_model = joblib.load('dbscan_model.pkl')
        except FileNotFoundError:
            dbscan_model = None
            
        # Load clustered data
        clustered_data = pd.read_csv('clustered_customers.csv')
        
        return kmeans_model, scaler, clustering_info, dbscan_model, clustered_data
    except FileNotFoundError as e:
        st.error(f"Model files not found. Please run the preprocessing notebook first. Error: {e}")
        return None, None, None, None, None

# Load everything
kmeans_model, scaler, clustering_info, dbscan_model, clustered_data = load_models_and_data()

def main():
    st.title("🛍️ Mall Customer Segmentation")
    st.markdown("---")
    
    if kmeans_model is None:
        st.stop()
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", [
        "🔮 Customer Prediction", 
        "📊 Cluster Analysis", 
        "📈 Visualizations",
        "🤖 Model Performance"
    ])
    
    if page == "🔮 Customer Prediction":
        prediction_page()
    elif page == "📊 Cluster Analysis":
        cluster_analysis_page()
    elif page == "📈 Visualizations":
        visualization_page()
    elif page == "🤖 Model Performance":
        model_performance_page()

def prediction_page():
    st.header("🔮 Predict Customer Segment")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Customer Information")
        
        with st.form("customer_form"):
            # Customer inputs
            age = st.slider("Age", 18, 70, 35)
            income = st.slider("Annual Income (k$)", 15, 140, 60)
            spending_score = st.slider("Spending Score (1-100)", 1, 100, 50)
            gender = st.selectbox("Gender", ["Male", "Female"])
            
            submitted = st.form_submit_button("🎯 Predict Segment", type="primary")
        
        if submitted:
            # Prepare input for prediction
            input_data = np.array([[income, spending_score]])
            input_scaled = scaler.transform(input_data)
            
            # Make prediction
            cluster_pred = kmeans_model.predict(input_scaled)[0]
            
            with col2:
                st.subheader("📊 Prediction Results")
                
                # Display cluster prediction
                st.metric("Customer Segment", f"Cluster {cluster_pred}")
                
                # Get cluster profile
                if cluster_pred in clustering_info['cluster_profiles']:
                    profile = clustering_info['cluster_profiles'][cluster_pred]
                    
                    st.write("**Segment Characteristics:**")
                    st.write(f"• Average Age: {profile['avg_age']:.1f}")
                    st.write(f"• Average Income: ${profile['avg_income']:.1f}k")
                    st.write(f"• Average Spending: {profile['avg_spending']:.1f}")
                    st.write(f"• Segment Size: {profile['size']} customers")
                
                # Provide segment interpretation
                segment_description = get_segment_description(cluster_pred, income, spending_score)
                st.subheader("💡 Segment Insights")
                st.write(segment_description)
                
                # Show similar customers
                st.subheader("👥 Similar Customers")
                similar_customers = clustered_data[clustered_data['Cluster'] == cluster_pred].sample(
                    min(5, len(clustered_data[clustered_data['Cluster'] == cluster_pred]))
                )
                st.dataframe(similar_customers[['Age', 'Gender', 'Annual Income (k$)', 'Spending Score (1-100)']])

def get_segment_description(cluster, income, spending_score):
    """Generate segment description based on cluster and input values"""
    descriptions = {
        0: "🎯 **Target Customers** - High income, high spending. Premium segment for luxury products.",
        1: "💰 **High Earners, Low Spenders** - Cautious with money despite high income. Focus on value proposition.",
        2: "🛒 **Average Customers** - Moderate income and spending. Mainstream market segment.",
        3: "💸 **Spenders** - Lower income but high spending. Price-sensitive but willing to spend on desired items.",
        4: "🏪 **Budget Conscious** - Lower income, lower spending. Focus on affordable, essential products."
    }
    
    # Default description if cluster not in predefined descriptions
    if cluster not in descriptions:
        if income > 70 and spending_score > 70:
            return "🌟 **Premium Segment** - High value customers with strong purchasing power."
        elif income > 70 and spending_score < 40:
            return "💎 **Conservative High Earners** - High income but careful spending habits."
        elif income < 40 and spending_score > 60:
            return "🛍️ **Enthusiastic Shoppers** - Lower income but high spending tendency."
        else:
            return "📊 **Standard Segment** - Average income and spending patterns."
    
    return descriptions.get(cluster, "📊 **Customer Segment** - Unique customer profile.")

def cluster_analysis_page():
    st.header("📊 Cluster Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🎯 Cluster Overview")
        
        # Display cluster summary
        for cluster, profile in clustering_info['cluster_profiles'].items():
            with st.expander(f"Cluster {cluster} ({profile['size']} customers)"):
                st.write(f"**Average Age:** {profile['avg_age']:.1f} years")
                st.write(f"**Average Income:** ${profile['avg_income']:.1f}k")
                st.write(f"**Average Spending Score:** {profile['avg_spending']:.1f}")
                st.write(f"**Dominant Gender:** {profile['dominant_gender']}")
                
                # Calculate percentage
                total_customers = sum(p['size'] for p in clustering_info['cluster_profiles'].values())
                percentage = (profile['size'] / total_customers) * 100
                st.write(f"**Market Share:** {percentage:.1f}%")
    
    with col2:
        st.subheader("📈 Cluster Distribution")
        
        # Pie chart of cluster sizes
        cluster_sizes = [profile['size'] for profile in clustering_info['cluster_profiles'].values()]
        cluster_labels = [f"Cluster {i}" for i in clustering_info['cluster_profiles'].keys()]
        
        fig_pie = px.pie(values=cluster_sizes, names=cluster_labels, 
                        title="Customer Distribution by Cluster")
        st.plotly_chart(fig_pie, use_container_width=True)
    
    # Detailed cluster statistics
    st.subheader("📋 Detailed Cluster Statistics")
    
    # Create summary table
    cluster_summary = []
    for cluster, profile in clustering_info['cluster_profiles'].items():
        cluster_summary.append({
            'Cluster': cluster,
            'Size': profile['size'],
            'Avg Age': f"{profile['avg_age']:.1f}",
            'Avg Income (k$)': f"{profile['avg_income']:.1f}",
            'Avg Spending Score': f"{profile['avg_spending']:.1f}",
            'Dominant Gender': profile['dominant_gender']
        })
    
    summary_df = pd.DataFrame(cluster_summary)
    st.dataframe(summary_df, use_container_width=True)

def visualization_page():
    st.header("📈 Data Visualizations")
    
    # Main cluster visualization
    st.subheader("🎯 Customer Clusters")
    
    # Interactive scatter plot
    fig_scatter = px.scatter(
        clustered_data, 
        x='Annual Income (k$)', 
        y='Spending Score (1-100)',
        color='Cluster',
        size='Age',
        hover_data=['Gender', 'Age'],
        title="Customer Segments (K-Means Clustering)",
        color_continuous_scale='viridis'
    )
    fig_scatter.update_layout(height=500)
    st.plotly_chart(fig_scatter, use_container_width=True)
    
    # Side-by-side comparisons
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Age Distribution by Cluster")
        fig_age = px.box(clustered_data, x='Cluster', y='Age', 
                        title="Age Distribution Across Clusters")
        st.plotly_chart(fig_age, use_container_width=True)
    
    with col2:
        st.subheader("👥 Gender Distribution")
        gender_cluster = clustered_data.groupby(['Cluster', 'Gender']).size().reset_index(name='Count')
        fig_gender = px.bar(gender_cluster, x='Cluster', y='Count', color='Gender',
                           title="Gender Distribution by Cluster", barmode='group')
        st.plotly_chart(fig_gender, use_container_width=True)
    
    # 3D Visualization
    st.subheader("🌐 3D Customer View")
    fig_3d = px.scatter_3d(
        clustered_data,
        x='Annual Income (k$)',
        y='Spending Score (1-100)',
        z='Age',
        color='Cluster',
        size='Spending Score (1-100)',
        hover_data=['Gender'],
        title="3D Customer Segmentation"
    )
    fig_3d.update_layout(height=600)
    st.plotly_chart(fig_3d, use_container_width=True)
    
    # Try to load saved plots
    try:
        st.subheader("📊 Additional Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Exploratory Data Analysis**")
            exploration_img = Image.open('customer_exploration.png')
            st.image(exploration_img, caption="Customer Data Exploration", use_column_width=True)
        
        with col2:
            st.write("**Optimal Clusters Analysis**")
            optimal_img = Image.open('optimal_clusters.png')
            st.image(optimal_img, caption="Elbow Method & Silhouette Analysis", use_column_width=True)
        
        # Cluster visualization
        st.write("**Detailed Cluster Visualization**")
        cluster_img = Image.open('cluster_visualization.png')
        st.image(cluster_img, caption="Comprehensive Cluster Analysis", use_column_width=True)
        
        # DBSCAN comparison if available
        try:
            st.write("**Clustering Algorithm Comparison**")
            dbscan_img = Image.open('dbscan_comparison.png')
            st.image(dbscan_img, caption="K-Means vs DBSCAN Comparison", use_column_width=True)
        except FileNotFoundError:
            st.info("DBSCAN comparison not available.")
            
    except FileNotFoundError:
        st.warning("Visualization files not found. Please run the preprocessing notebook first.")

def model_performance_page():
    st.header("🤖 Model Performance")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 K-Means Performance")
        
        st.write("**Model Metrics:**")
        st.write(f"• Optimal Clusters: {clustering_info['optimal_k']}")
        st.write(f"• Silhouette Score: {clustering_info['silhouette_score_kmeans']:.3f}")
        st.write(f"• Total Customers: {sum(p['size'] for p in clustering_info['cluster_profiles'].values())}")
        
        # Silhouette score interpretation
        silhouette_score = clustering_info['silhouette_score_kmeans']
        if silhouette_score > 0.7:
            st.success("🌟 Excellent clustering quality!")
        elif silhouette_score > 0.5:
            st.info("👍 Good clustering quality")
        elif silhouette_score > 0.25:
            st.warning("⚠️ Average clustering quality")
        else:
            st.error("❌ Poor clustering quality")
    
    with col2:
        st.subheader("🔍 Algorithm Comparison")
        
        if 'silhouette_score_dbscan' in clustering_info:
            st.write("**DBSCAN Performance:**")
            st.write(f"• Optimal eps: {clustering_info['dbscan_eps']}")
            st.write(f"• Silhouette Score: {clustering_info['silhouette_score_dbscan']:.3f}")
            
            # Compare algorithms
            comparison_data = {
                'Algorithm': ['K-Means', 'DBSCAN'],
                'Silhouette Score': [clustering_info['silhouette_score_kmeans'], 
                                   clustering_info['silhouette_score_dbscan']],
                'Clusters': [clustering_info['optimal_k'], 'Variable']
            }
            comparison_df = pd.DataFrame(comparison_data)
            st.dataframe(comparison_df)
        else:
            st.info("DBSCAN results not available.")
    
    # Elbow method visualization
    st.subheader("📈 Elbow Method Analysis")
    
    # Create interactive elbow plot
    fig_elbow = go.Figure()
    
    fig_elbow.add_trace(go.Scatter(
        x=clustering_info['k_range'],
        y=clustering_info['silhouette_scores'],
        mode='lines+markers',
        name='Silhouette Score',
        line=dict(color='blue', width=3),
        marker=dict(size=8)
    ))
    
    fig_elbow.update_layout(
        title="Silhouette Score vs Number of Clusters",
        xaxis_title="Number of Clusters (k)",
        yaxis_title="Silhouette Score",
        height=400
    )
    
    st.plotly_chart(fig_elbow, use_container_width=True)
    
    # Model explanation
    st.subheader("🧠 How It Works")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**K-Means Clustering:**")
        st.write("""
        • Groups customers into k clusters
        • Minimizes within-cluster variance
        • Uses customer income and spending patterns
        • Finds centroids that represent cluster centers
        • Good for spherical, similar-sized clusters
        """)
    
    with col2:
        st.write("**DBSCAN Clustering:**")
        st.write("""
        • Density-based clustering algorithm
        • Finds clusters of varying shapes and sizes
        • Can identify outliers as noise points
        • Does not require pre-specifying number of clusters
        • Good for irregularly shaped clusters
        """)
    
    # Feature importance
    st.subheader("🎯 Feature Analysis")
    
    st.write("**Features Used for Clustering:**")
    for i, feature in enumerate(clustering_info['feature_columns'], 1):
        st.write(f"{i}. {feature}")
    
    # Display cluster centers
    st.subheader("📍 Cluster Centers (K-Means)")
    if hasattr(kmeans_model, 'cluster_centers_'):
        centers_original = scaler.inverse_transform(kmeans_model.cluster_centers_)
        centers_df = pd.DataFrame(
            centers_original,
            columns=clustering_info['feature_columns'],
            index=[f"Cluster {i}" for i in range(len(centers_original))]
        )
        st.dataframe(centers_df.round(2))

def add_footer():
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: gray;'>"
        "🛍️ Mall Customer Segmentation | Built with Streamlit & scikit-learn"
        "</div>", 
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()
    add_footer()