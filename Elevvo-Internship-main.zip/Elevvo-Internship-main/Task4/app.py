import streamlit as st
import pandas as pd
import numpy as np
import joblib
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings('ignore')

# Set page configuration
st.set_page_config(
    page_title="Loan Approval Predictor",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #2E86C1;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #2874A6;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #F8F9FA;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #2E86C1;
        margin: 0.5rem 0;
    }
    .success-message {
        background-color: #D5EFDF;
        color: #0F5132;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #198754;
    }
    .warning-message {
        background-color: #FFF3CD;
        color: #664D03;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #FFC107;
    }
    .danger-message {
        background-color: #F8D7DA;
        color: #721C24;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #DC3545;
    }
</style>
""", unsafe_allow_html=True)

# Main title
st.markdown('<div class="main-header">🏦 Loan Approval Prediction System</div>', 
            unsafe_allow_html=True)

def safe_label_encode(encoder, value, column_name):
    """Safely encode labels, handling unseen categories"""
    try:
        return encoder.transform([value])[0]
    except ValueError:
        # If the value is not in the encoder's classes, return the most common class
        st.warning(f"Unseen value '{value}' for {column_name}. Using default encoding.")
        return 0  # Default to first class

@st.cache_resource
def load_model_artifacts():
    """Load pre-trained model and preprocessing objects"""
    try:
        model = joblib.load('loan_approval_model.pkl')
        scaler = joblib.load('loan_scaler.pkl')
        label_encoders = joblib.load('label_encoders.pkl')
        target_encoder = joblib.load('target_encoder.pkl')
        feature_columns = joblib.load('feature_columns.pkl')
        
        return model, scaler, label_encoders, target_encoder, feature_columns
    except FileNotFoundError as e:
        st.error(f"Model files not found: {e}")
        st.info("Please run the Jupyter notebook first to train and save the model.")
        st.info("Make sure these files exist: loan_approval_model.pkl, loan_scaler.pkl, label_encoders.pkl, target_encoder.pkl, feature_columns.pkl")
        return None, None, None, None, None

def create_gauge_chart(probability, title):
    """Create a gauge chart for probability visualization"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = probability * 100,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title},
        delta = {'reference': 50},
        gauge = {
            'axis': {'range': [None, 100]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 25], 'color': "lightgray"},
                {'range': [25, 50], 'color': "gray"},
                {'range': [50, 75], 'color': "lightgreen"},
                {'range': [75, 100], 'color': "green"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 90
            }
        }
    ))
    fig.update_layout(height=300)
    return fig

def calculate_financial_ratios(data):
    """Calculate financial ratios for additional insights"""
    ratios = {}
    ratios['Loan to Income Ratio'] = data['loan_amount'] / data['income_annum']
    ratios['Total Assets'] = (data['residential_assets_value'] + 
                             data['commercial_assets_value'] + 
                             data['luxury_assets_value'] + 
                             data['bank_asset_value'])
    ratios['Asset to Loan Ratio'] = ratios['Total Assets'] / data['loan_amount']
    ratios['Debt to Income Ratio'] = data['loan_amount'] / data['income_annum'] * 100
    
    return ratios

def get_risk_assessment(probability, ratios):
    """Provide risk assessment based on probability and ratios"""
    if probability >= 0.8:
        risk_level = "Low Risk"
        risk_color = "success"
        risk_message = "Strong likelihood of approval with favorable financial profile."
    elif probability >= 0.6:
        risk_level = "Medium Risk"
        risk_color = "warning"
        risk_message = "Moderate likelihood of approval. Consider improving financial metrics."
    else:
        risk_level = "High Risk"
        risk_color = "danger"
        risk_message = "Lower likelihood of approval. Significant financial improvements recommended."
    
    return risk_level, risk_color, risk_message

# Load model artifacts
model, scaler, label_encoders, target_encoder, feature_columns = load_model_artifacts()

if model is None:
    st.stop()

# Sidebar for input
st.sidebar.markdown("## 📝 Application Details")

# Create two columns for the main content
col1, col2 = st.columns([1, 1])

with st.sidebar:
    st.markdown("### Personal Information")
    
    no_of_dependents = st.number_input(
        "Number of Dependents",
        min_value=0,
        max_value=10,
        value=2,
        help="Number of people dependent on the applicant"
    )
    
    education = st.selectbox(
        "Education Level",
        options=["Graduate", "Not Graduate"],
        help="Highest education qualification"
    )
    
    self_employed = st.selectbox(
        "Employment Type",
        options=["No", "Yes"],
        help="Are you self-employed?"
    )
    
    st.markdown("### Financial Information")
    
    income_annum = st.number_input(
        "Annual Income (₹)",
        min_value=100000,
        max_value=50000000,
        value=5000000,
        step=100000,
        help="Total annual income in rupees"
    )
    
    loan_amount = st.number_input(
        "Loan Amount (₹)",
        min_value=100000,
        max_value=100000000,
        value=10000000,
        step=100000,
        help="Requested loan amount in rupees"
    )
    
    loan_term = st.slider(
        "Loan Term (Years)",
        min_value=1,
        max_value=30,
        value=15,
        help="Loan repayment period in years"
    )
    
    cibil_score = st.slider(
        "CIBIL Score",
        min_value=300,
        max_value=900,
        value=650,
        help="Credit score (300-900)"
    )
    
    st.markdown("### Asset Information")
    
    residential_assets = st.number_input(
        "Residential Assets Value (₹)",
        min_value=0,
        max_value=100000000,
        value=5000000,
        step=100000,
        help="Value of residential properties"
    )
    
    commercial_assets = st.number_input(
        "Commercial Assets Value (₹)",
        min_value=0,
        max_value=100000000,
        value=2000000,
        step=100000,
        help="Value of commercial properties"
    )
    
    luxury_assets = st.number_input(
        "Luxury Assets Value (₹)",
        min_value=0,
        max_value=100000000,
        value=1000000,
        step=100000,
        help="Value of luxury items (cars, jewelry, etc.)"
    )
    
    bank_assets = st.number_input(
        "Bank Assets Value (₹)",
        min_value=0,
        max_value=100000000,
        value=3000000,
        step=100000,
        help="Value of bank deposits and investments"
    )
    
    # Prediction button
    predict_button = st.button("🔮 Predict Loan Approval", type="primary", use_container_width=True)

# Main content area
with col1:
    st.markdown('<div class="section-header">📊 Application Summary</div>', unsafe_allow_html=True)
    
    # Create input data
    input_data = {
        'no_of_dependents': no_of_dependents,
        'income_annum': income_annum,
        'loan_amount': loan_amount,
        'loan_term': loan_term,
        'cibil_score': cibil_score,
        'residential_assets_value': residential_assets,
        'commercial_assets_value': commercial_assets,
        'luxury_assets_value': luxury_assets,
        'bank_asset_value': bank_assets
    }
    
    # Display key metrics
    col1_1, col1_2 = st.columns(2)
    
    with col1_1:
        st.metric("Annual Income", f"₹{income_annum:,}")
        st.metric("Loan Amount", f"₹{loan_amount:,}")
        st.metric("CIBIL Score", cibil_score)
    
    with col1_2:
        st.metric("Loan Term", f"{loan_term} years")
        st.metric("Dependents", no_of_dependents)
        total_assets = residential_assets + commercial_assets + luxury_assets + bank_assets
        st.metric("Total Assets", f"₹{total_assets:,}")
    
    # Calculate and display financial ratios
    ratios = calculate_financial_ratios(input_data)
    
    st.markdown("### 📈 Financial Ratios")
    
    ratio_col1, ratio_col2 = st.columns(2)
    with ratio_col1:
        st.info(f"**Loan to Income Ratio:** {ratios['Loan to Income Ratio']:.2f}")
        st.info(f"**Debt to Income Ratio:** {ratios['Debt to Income Ratio']:.1f}%")
    
    with ratio_col2:
        st.info(f"**Asset to Loan Ratio:** {ratios['Asset to Loan Ratio']:.2f}")
        st.info(f"**Total Assets:** ₹{ratios['Total Assets']:,.0f}")

with col2:
    st.markdown('<div class="section-header">🎯 Prediction Results</div>', unsafe_allow_html=True)
    
    if predict_button:
        try:
            # Debug: Show what encoders are available
            if st.checkbox("Show debug info", value=False):
                st.write("Available encoders:", list(label_encoders.keys()))
                for key, encoder in label_encoders.items():
                    st.write(f"{key} classes:", encoder.classes_)
            
            # Prepare the data for prediction
            prediction_data = input_data.copy()
            
            # Add encoded categorical variables with error handling
            try:
                prediction_data['education_encoded'] = safe_label_encode(
                    label_encoders['education'], education, 'education'
                )
                prediction_data['self_employed_encoded'] = safe_label_encode(
                    label_encoders['self_employed'], self_employed, 'self_employed'
                )
            except KeyError as ke:
                st.error(f"Missing encoder: {ke}")
                st.stop()
            
            # Add engineered features
            prediction_data['loan_to_income_ratio'] = ratios['Loan to Income Ratio']
            prediction_data['total_assets'] = ratios['Total Assets']
            prediction_data['asset_to_loan_ratio'] = ratios['Asset to Loan Ratio']
            
            # Debug: Show feature order
            if st.checkbox("Show feature order", value=False):
                st.write("Expected feature order:", feature_columns)
                st.write("Prediction data keys:", list(prediction_data.keys()))
            
            # Create feature vector in the correct order
            try:
                feature_vector = np.array([[prediction_data[col] for col in feature_columns]])
            except KeyError as ke:
                st.error(f"Missing feature in prediction data: {ke}")
                st.write("Available features:", list(prediction_data.keys()))
                st.stop()
            
            # Scale the features
            feature_vector_scaled = scaler.transform(feature_vector)
            
            # Make prediction
            prediction = model.predict(feature_vector_scaled)[0]
            prediction_proba = model.predict_proba(feature_vector_scaled)[0]
            
            # Get prediction label
            prediction_label = target_encoder.inverse_transform([prediction])[0]
            approval_probability = prediction_proba[1]  # Probability of approval
            
            # Display results
            if prediction_label == "Approved":
                st.markdown(f'''
                <div class="success-message">
                    <h3>✅ Loan Likely to be APPROVED</h3>
                    <p><strong>Confidence:</strong> {approval_probability:.1%}</p>
                </div>
                ''', unsafe_allow_html=True)
            else:
                st.markdown(f'''
                <div class="danger-message">
                    <h3>❌ Loan Likely to be REJECTED</h3>
                    <p><strong>Confidence:</strong> {(1-approval_probability):.1%}</p>
                </div>
                ''', unsafe_allow_html=True)
            
            # Create gauge chart
            gauge_fig = create_gauge_chart(approval_probability, "Approval Probability")
            st.plotly_chart(gauge_fig, use_container_width=True)
            
            # Risk assessment
            risk_level, risk_color, risk_message = get_risk_assessment(approval_probability, ratios)
            
            if risk_color == "success":
                st.success(f"**{risk_level}:** {risk_message}")
            elif risk_color == "warning":
                st.warning(f"**{risk_level}:** {risk_message}")
            else:
                st.error(f"**{risk_level}:** {risk_message}")
            
            # Detailed probability breakdown
            st.markdown("### 📊 Probability Breakdown")
            prob_df = pd.DataFrame({
                'Outcome': ['Rejected', 'Approved'],
                'Probability': [prediction_proba[0], prediction_proba[1]]
            })
            
            fig_bar = px.bar(prob_df, x='Outcome', y='Probability', 
                           color='Outcome',
                           color_discrete_map={'Approved': '#28a745', 'Rejected': '#dc3545'},
                           title="Prediction Probabilities")
            fig_bar.update_layout(showlegend=False, height=400)
            st.plotly_chart(fig_bar, use_container_width=True)
            
        except Exception as e:
            st.error(f"Error making prediction: {str(e)}")
            st.error("Please ensure the model was trained properly and all required files exist.")
            
            # Additional debugging info
            with st.expander("🔧 Debug Information"):
                st.write("Error details:", str(e))
                st.write("Input data:", input_data)
                if 'prediction_data' in locals():
                    st.write("Prediction data:", prediction_data)
                st.write("Make sure you've run the Jupyter notebook to train the model first!")
    
    else:
        st.info("👆 Fill in the application details and click 'Predict Loan Approval' to see results.")

# Additional insights section
st.markdown('<div class="section-header">💡 Key Insights & Recommendations</div>', unsafe_allow_html=True)

insight_col1, insight_col2, insight_col3 = st.columns(3)

with insight_col1:
    st.markdown("### 🎯 CIBIL Score Impact")
    if cibil_score >= 750:
        st.success("Excellent credit score! This significantly improves approval chances.")
    elif cibil_score >= 650:
        st.warning("Good credit score. Consider improving to 750+ for better rates.")
    else:
        st.error("Credit score needs improvement. Focus on timely payments and reducing debt.")

with insight_col2:
    st.markdown("### 💰 Financial Health")
    loan_to_income = loan_amount / income_annum
    if loan_to_income <= 3:
        st.success("Healthy loan-to-income ratio. Low financial risk.")
    elif loan_to_income <= 5:
        st.warning("Moderate loan-to-income ratio. Manageable but monitor carefully.")
    else:
        st.error("High loan-to-income ratio. Consider reducing loan amount or increasing income.")

with insight_col3:
    st.markdown("### 🏠 Asset Coverage")
    asset_coverage = total_assets / loan_amount
    if asset_coverage >= 2:
        st.success("Strong asset coverage provides excellent security.")
    elif asset_coverage >= 1:
        st.warning("Adequate asset coverage. Consider increasing assets if possible.")
    else:
        st.error("Low asset coverage. Building more assets would strengthen application.")

# Model information
with st.expander("ℹ️ About This Model"):
    st.markdown("""
    ### Model Information
    - **Algorithm**: Machine Learning ensemble with SMOTE for class imbalance
    - **Features**: 14 key financial and personal indicators
    - **Training Data**: 4,269 historical loan applications
    - **Performance**: Optimized for precision, recall, and F1-score
    
    ### Key Factors Considered
    - Personal information (dependents, education, employment)
    - Financial profile (income, assets, credit score)
    - Loan characteristics (amount, term)
    - Calculated ratios (loan-to-income, asset coverage)
    
    ### Disclaimer
    This prediction is based on historical data and should be used as a guidance tool only. 
    Actual loan approval decisions may vary based on additional factors and current lending policies.
    """)

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666; padding: 1rem;'>
    🏦 Loan Approval Prediction System | Built with Streamlit & Machine Learning
</div>
""", unsafe_allow_html=True)