# movie-recommender-system-tmdb-dataset
A content based movie recommender system using cosine similarity
